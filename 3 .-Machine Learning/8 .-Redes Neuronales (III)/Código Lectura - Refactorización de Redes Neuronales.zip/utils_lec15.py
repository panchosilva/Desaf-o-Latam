#!/usr/bin/env python
# -*- coding: utf-8 -*-

import pandas as pd
import numpy as np


"""
File: utils_lec15.py
Author: Ignacio Soto Zamorano
Email: ignacio[dot]soto[dot]z[at]gmail[dot]com
Github: https://github.com/ignaciosotoz
Description: Ancilliary File for Recurrent Neural Nets - ADL
"""

def create_dataset(data, lag_n = 1):
    """TODO: Docstring for create_dataset.

    :data: TODO
    :lag_n: TODO
    :returns: TODO

    """
    # generamos dos listas que guardan la matriz de atributos y el vector objetivo
    train, target = [], []
    # para facilitar el trabajo, ingestaremos los datos en un dataframe
    tmp_df = pd.DataFrame(data)
    
    # para cada registro
    for index, row in tmp_df.itertuples():
        # extraemos los valores
        train.append(tmp_df.iloc[index: index + lag_n].values)
        target.append(tmp_df.iloc[index + lag_n].values)
        if (index + lag_n + 1) == tmp_df.shape[0]:
            break
    return np.array(train), np.expand_dims(np.array(target), axis = 2)
